<template>
 <div>  
    <a-menu
      class="home-container"     
      style="width: 190px"
      :open-keys.sync="openKeys"
      mode="inline"
      @click="handleClick"     
    >
    <a-menu-item key="1">
        <a-icon type="pie-chart" />
        <span>经营简报</span>
      </a-menu-item>
      <a-menu-item key="2">
        <a-icon type="desktop" />
        <span>存贷结构</span>
      </a-menu-item>
    </a-menu>  
  </div>
</template>


<script lang="ts">
import { Component, Vue } from "vue-property-decorator";

@Component
export default class Home extends Vue {}
</script>

<style lang="less" scoped>
.home-container{
  position: fixed;
    left: 0;
    top: 48px;
    bottom: 0;
}
</style>
