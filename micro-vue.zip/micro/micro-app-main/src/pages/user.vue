<template>
  <div>
    <section class="user-menu">
    <a-menu v-model="current" mode="horizontal">
    <a-sub-menu>
        <span slot="title" class="submenu-title-wrapper"
          ><a-icon type="setting" />Navigation Three - Submenu</span
        >
        <a-menu-item-group title="Item 1">
          <a-menu-item key="setting:1">
            Option 1
          </a-menu-item>
          <a-menu-item key="setting:2">
            Option 2
          </a-menu-item>
        </a-menu-item-group>
    </a-sub-menu>
    </a-menu>
  </div>
</template>  