<template>
  <section style="padding: 20px; color: red;">Vue App</section>
</template>
<script>
export default {
  name: "Home"
}
</script>