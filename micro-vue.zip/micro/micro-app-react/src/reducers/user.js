export function dataSource (state = [], action) {
  switch (action.type) {

    default:
      return state;
  }
}

export function formValues (state = {}, action) {
  switch (action.type) {
    default:
      return state;
  }
}

export function editTarget (state = null, action) {
  switch (action.type) {
    default:
      return state;
  }
}
