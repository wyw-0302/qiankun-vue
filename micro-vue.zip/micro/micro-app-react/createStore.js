import { combineReducers } from 'redux';

export default function (initialState) {

}
