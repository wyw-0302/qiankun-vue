import React from "react";

const Home = () => <section style={{ padding: 20 }}>React App</section>

export default Home;