本仓库基于 `qiankun` 实现微前端架构，运行命令（全量启动）如下：

yarn install
yarn examples:install
yarn examples:start


